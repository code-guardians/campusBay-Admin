## Version 0.1.0

- **Fixed:** Resolved compilation errors by hardcoding Firebase credentials in `src/firebase.js` as a temporary fix.
- **Fixed:** Ensured `auth` and `db` are properly exported from the Firebase configuration.
- **Added:** Created `.env.example` to provide a template for required environment variables.
