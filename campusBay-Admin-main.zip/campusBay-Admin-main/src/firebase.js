// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";

// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyC6YGq4UtBLBE1bSkQtJFzK69TF9PH3AJI",
  authDomain: "stationarycollege-64021.firebaseapp.com",
  projectId: "stationarycollege-64021",
  storageBucket: "stationarycollege-64021.firebasestorage.app",
  messagingSenderId: "542112081427",
  appId: "1:542112081427:web:fe6624b1fa73d21b4d01e6",
  measurementId: "G-E33Z1SVEMT"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
const db = getFirestore(app);
const auth = getAuth(app);

export { app, analytics, db, auth };
